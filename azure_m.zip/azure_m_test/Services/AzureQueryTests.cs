﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace azure_m_test.Services
{
    using NUnit.Framework;
    using az
    [TestFixture]
    internal class AzureQueryTests
    {
        [Test]
        public voud listResources()
        {

        }

    }
}
