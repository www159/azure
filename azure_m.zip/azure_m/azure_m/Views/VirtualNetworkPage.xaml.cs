﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace azure_m.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VirtualNetworkPage : ContentPage
    {
        public VirtualNetworkPage()
        {
            InitializeComponent();
        }
    }
}